<div align="center">

# Leafer HTMLText Editor

**Rich text editor plugin for Leafer UI** · Powered by Quill 2.0 · HTML text & full styling control

<br>

[![npm version](https://img.shields.io/npm/v/@chenyomi/leafer-htmltext-edit.svg?style=flat-square)](https://www.npmjs.com/package/@chenyomi/leafer-htmltext-edit)
[![npm downloads](https://img.shields.io/npm/dm/@chenyomi/leafer-htmltext-edit.svg?style=flat-square)](https://www.npmjs.com/package/@chenyomi/leafer-htmltext-edit)
[![license](https://img.shields.io/npm/l/@chenyomi/leafer-htmltext-edit.svg?style=flat-square)](./LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-Ready-3178C6?style=flat-square&logo=typescript&logoColor=white)](https://www.typescriptlang.org/)

<br>

[中文](./README.md) · [📖 Documentation](https://chenyomi.github.io/leafer-htmltext-edit-website/docs) · [Live Demo](https://chenyomi.github.io/leafer-htmltext-edit-view/) · [Website](https://chenyomi.github.io/leafer-htmltext-edit-website/)

</div>

---

## ✨ Features

| | |
| :--- | :--- |
| 🎨 **Rich Text Editing** | Built on Quill 2.0 with full rich text editing capabilities |
| 📐 **Text Styling** | Font, size, color, alignment, line height, letter spacing, and more |
| 🖊️ **Inline Stroke** | Per-character `textStroke` inline stroke effect |
| 💪 **Inline Font Weight** | Selection-level `bold` / `fontWeight` inline control |
| 📋 **List Support** | Ordered and unordered lists |
| 🔐 **License Management** | Built-in licensing — no limits for local dev, license check for production |
| 🔧 **TypeScript** | Full type definition support |
| 🚀 **Modern Build** | ESM + CJS dual format with Tree Shaking support |

---

## 🔗 Links

| Resource | Link |
| :--- | :--- |
| 📖 Documentation | [chenyomi.github.io/leafer-htmltext-edit-website/docs](https://chenyomi.github.io/leafer-htmltext-edit-website/docs) |
| 🌐 Website | [chenyomi.github.io/leafer-htmltext-edit-website](https://chenyomi.github.io/leafer-htmltext-edit-website/) |
| 🎮 Live Demo | [chenyomi.github.io/leafer-htmltext-edit-view](https://chenyomi.github.io/leafer-htmltext-edit-view/) |
| 🐛 Issues | [GitHub Issues](https://github.com/chenyomi/leafer-htmltext-edit-view/issues) |

> For usage guides, API reference, and FAQ, see the **[official documentation](https://chenyomi.github.io/leafer-htmltext-edit-website/docs)**.

---

## 📦 Installation

```bash
npm install @chenyomi/leafer-htmltext-edit
```

Or with other package managers:

```bash
pnpm add @chenyomi/leafer-htmltext-edit
# yarn
yarn add @chenyomi/leafer-htmltext-edit
```

### Peer Dependencies

The plugin requires the following packages — make sure they are installed:

```bash
npm install leafer-ui @leafer-ui/core @leafer-in/editor @leafer-in/html quill
```

| Package | Description |
| :--- | :--- |
| `leafer-ui` | Leafer UI main package |
| `@leafer-ui/core` | Leafer core |
| `@leafer-in/editor` | Editor extension |
| `@leafer-in/html` | HTML rendering support |
| `quill` | Rich text engine |

---

## 📄 License

This project is distributed under a custom commercial license. See [LICENSE](./LICENSE) for details.

Commercial use requires a license key. Please contact the author for authorization.

---

<div align="center">

### 👤 Author

**chenyomi** · [408550179@qq.com](mailto:408550179@qq.com)

<br>

If this project helps you, please give it a ⭐️ Star!

</div>
